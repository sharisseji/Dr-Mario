# list = [0,0,0,0]

class test():
    def __init__(self):
        self.list = [0]*2

    def __str__(self):
        return self.list

testobject = test()
print(testobject.__str__())
