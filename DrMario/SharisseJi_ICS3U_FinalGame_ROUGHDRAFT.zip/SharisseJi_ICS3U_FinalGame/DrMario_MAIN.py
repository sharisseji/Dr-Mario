#############################################
#   Programmer: Sharisse Ji                 #
#   Date: January 12, 2023                  #
#   File Name: DrMario_CLASSES.py           #
#   Description: Dr Mario main program      #
#############################################


from DrMario_CLASSES import *
from random import randint
import pygame
import time
pygame.init()

# LOAD GAME SCREEN
# width: height = 32:28
WIDTH = 800
HEIGHT = 700
GRIDSIZE = HEIGHT//28  # side lenght of one square = 25
screen = pygame.display.set_mode((WIDTH, HEIGHT))

# GAME SCREEN DIMENSIONS----------------------------------
COLUMNS = 8
ROWS = 16
LEFT = 11
RIGHT = LEFT + COLUMNS
MIDDLE = LEFT + COLUMNS//2
TOP = 8
FLOOR = TOP + ROWS

# COLOURS -----------------------
DARKGREY = (150,150,150)

# GAME VARIABLES----------------------
Play = True
# pill = Tile(1, 1, randint(1,3))
pill1 = Pill(MIDDLE,TOP)
# pill2 = Pill(6,1)
# pill3 = Pill(11,1)
# pill4 = Pill(16,1)
# pill5 = Pill(21,1)

floor = Bottom(LEFT, FLOOR, COLUMNS)
leftWall = Wall(LEFT-1, TOP, ROWS)
rightWall = Wall(RIGHT, TOP, ROWS)

obstacle = Obstacles(LEFT,FLOOR)

timer = 0
speed = 10

# FUNCTIONS---------------------------
def drawGrid():
    # draws faint gray lines in play screen
    # screen.fill((0,0,0))
    for x in range(0, WIDTH, GRIDSIZE):    # draw vertical
        pygame.draw.line(screen, DARKGREY, (x, 0), (x, HEIGHT))

    for y in range(0, HEIGHT, GRIDSIZE):     # draw horizontal
        pygame.draw.line(screen, DARKGREY, (0, y), (WIDTH, y))

    floor.draw(screen, GRIDSIZE)
    leftWall.draw(screen, GRIDSIZE)
    rightWall.draw(screen, GRIDSIZE)


def redrawScreen():
    # testing pill
    screen.fill((0,0,0))
    drawGrid()
    pill1.draw(screen, GRIDSIZE)
    print(pill1.__str__())

    pygame.display.update()


while Play:
    # TIMER
    timer = pygame.time.get_ticks() // 100
    time.sleep(0.08)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Play = False
        if event.type == pygame.KEYDOWN:

            if event.key == pygame.K_UP:
                pill1.rotateClock()
                if pill1.collides(leftWall) or pill1.collides(rightWall) or pill1.collides(floor):
                    pill1.rotateCounterClock()

            if event.key == pygame.K_LEFT:
                pill1.moveLeft()
                if pill1.collides(leftWall):
                    pill1.moveRight()

            if event.key == pygame.K_RIGHT:
                pill1.moveRight()
                if pill1.collides(rightWall):
                    pill1.moveLeft()


    if timer % speed == 0:
        pill1.moveDown()
        if pill1.collides(floor):
            pill1.moveUp()
            # Obstacles.append(pill1)

    redrawScreen()
    # pill = Tile(1, 1, randint(1,3))