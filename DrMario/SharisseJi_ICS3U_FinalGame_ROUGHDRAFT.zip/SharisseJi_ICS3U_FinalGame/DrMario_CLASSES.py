#############################################
#   Programmer: Sharisse Ji                 #
#   Date: January 12, 2023                  #
#   File Name: DrMario_CLASSES.py           #
#   Description: Dr Mario main program      #
#############################################

import pygame
from random import randint

# ------ COLOURS ----------#
BLACK = (0, 0, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
WHITE = (255, 255, 255)
GREY = (192, 192, 192)
COLOURS = [RED,  BLUE, YELLOW, BLACK, WHITE]
CLRNames = ['red', 'blue', 'yellow', 'black', 'white']
#            [0,    1          2        3       4]


class Tile(object):
    def __init__(self, x = 1, y = 1, clr = 0):
        self.x = x
        self.y = y
        self.clr = clr  # colour of the tile)

    def __str__(self):
        return '('+str(self.x)+','+str(self.y)+') '+CLRNames[self.clr]

    def __eq__(self, other):
        if self.x == other.x and self.y == other.y:
            return True
        return False

    def draw(self, surface, gridsize=25):  # gridsize will be held with GRIDSIZE variable from main
        tileX = self.x *gridsize
        tileY = self.y*gridsize
        CLR = COLOURS[self.clr]
        pygame.draw.rect(surface, CLR, (tileX, tileY,gridsize,gridsize),0)
        pygame.draw.rect(surface, WHITE, (tileX, tileY, gridsize+1, gridsize+1),1)

    def moveDown(self):
        self.y = self.y + 1

    def moveUp(self):
        self.y = self.y - 1


class Group(object):
    def __init__(self, groupX = 1, groupY=1, groupTileNo = 2):  # for pill, blockNo will be 2
        self.x = groupX
        self.y = groupY
        self.tiles = [Tile()]*groupTileNo
        self.Xoffset = [0]*groupTileNo  # need to be the same as in the Pill class
        self.Yoffset = [0]*groupTileNo
        self.clr = []

        for i in range(groupTileNo):
            i = randint(0,2)
            self.clr.append(i)

    def __str__(self):
        return self.Xoffset

    def _update(self):  # draws group of tiles using lists of tile class
        for i in range((len(self.tiles))):
            tileX = self.x + self.Xoffset[i]  # + offsets
            tileY = self.y + self.Yoffset[i]
            tileColour = self.clr[i]
            self.tiles[i] = Tile(tileX, tileY, tileColour)

    def draw(self, surface, gridsize):
        for tile in self.tiles:
            tile.draw(surface, gridsize)

    def collides(self, other):
        for tile in self.tiles:
            for obstacle in other.tiles:
                if tile == obstacle:
                    return True
        return False

    def append(self, other):  # for use in Obstacles class
        for tile in other.tiles:
            self.tiles.append(tile)


class Pill(Group):
    def __init__(self, x=1, y=1, tileNo = 2):  # given from the outside
        Group.__init__(self, x, y, tileNo)  # inherit everything from __init__ in Group class
        self.x = x
        self.y = y
        self._rot = 2
        self.Xoffset = [0,0] # stay 2!
        self.Yoffset = [0,0]
        self._rotate()


    def _rotate(self):
        #                    o             x
        #           o x      x     x o     o
        Xoffset = [[-1,0], [0,0], [0,-1], [0,0]]
        Yoffset = [[0,0], [-1,0], [0,0], [0,-1]]
        self.Xoffset = Xoffset[self._rot]
        self.Yoffset = Yoffset[self._rot]
        self._update()

    # MOVE THE PILL ----------------------#
    def moveLeft(self):
        self.x = self.x - 1
        self._update()

    def moveRight(self):
        self.x = self.x + 1
        self._update()

    def moveDown(self):
        self.y = self.y + 1
        self._update()

    def moveUp(self):
        self.y = self.y - 1
        self._update()

    # ROTATE THE PILL
    def rotateClock(self):
        self._rot = (self._rot+1) % 4
        self._rotate()

    def rotateCounterClock(self):
        self._rot = (self._rot-1) % 4
        self._rotate()


class Obstacles(object):
    def __init__(self, x=0, y=0, tileNo=0):
        Group.__init__(self, x, y, tileNo)

    def findFour(self, top, bottom, columns):   # checks if the row is full of blocks
        pass

    def removeFour(self, fullRows):             # if row is full, remove that row
        pass


class Bottom(Group):
    def __init__(self,x=1, y=1, tileNo=1):
        Group.__init__(self, x,y, tileNo)
        self.clr = [4]*tileNo  # draw it white
        for i in range(0,tileNo):
            self.Xoffset[i] = i
        self._update()


class Wall(Group):                                # Loads the wall blocks
    def __init__(self, x=1, y=1, tileNo=1):
        Group.__init__(self, x, y, tileNo)
        self.clr = [4]*tileNo  # draw it white
        for i in range(0,tileNo):                   # Vertical line of blocks
            self.Yoffset[i] = i
        self._update()

